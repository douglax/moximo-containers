
<?php 

var_export($_SERVER) ;
?>


<hr>


<?php 

phpinfo();
?>


